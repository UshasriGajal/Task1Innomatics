// number
let age = 21
console.log(age)
console.log(typeof(age))

// string
let Name = "Usha"
console.log(Name)
console.log(typeof(Name))

// Boolean
let bool= age == Name
console.log(bool)
console.log(typeof(bool))

// undefined
let value
console.log(value)
console.log(typeof(value))

// null
let nullvalue = null
console.log(nullvalue)
console.log(typeof(nullvalue))

// Declaration
var num1 = 10
console.log(num1)

let num2 = 20
console.log(num2)

const num3 = 40
console.log(num3)

// Operators
// Addition
console.log("Addition= ",num1 + num2)

// subtraction
console.log("Subtraction= ",num2 - num1)

// Multiplication
console.log("Multiplication= ",num2 * num1)

// division
console.log("Division= ",num1 / num2)

// Modulus
console.log("Modulus= ",num1 % num2)

// comparision operators
// equal to
console.log("Equal to = ",num2 == num1)

// Triple equal to

console.log("Triple equal to = ",num2 === num1)

// Not equal to
console.log("Not equal to = ",num2 != num1)
console.log("Not equal to = ",num2 !== num1)


// Greaterthan 
console.log("Greaterthan = ",num2 > num1)

// lessthan
console.log("lessthan = ",num2 < num1)

// Greaterthan or equal to
console.log("Greaterthan or equal to = ",num2 >= num1)

// Lessthan or equal to
console.log("Lessthan or equal to = ",num2 <= num1)

// And operators
console.log("And operator ",num2 && num1)

// or operators
console.log("Or operator = ",num2 || num1)

